### FODtoPascal.py

To use: Change the lines of code under the settings comment at the end of the python file.

Settings:
	directory_to_convert = Target dataset directory
	output_directory = Location of final converted dataset
	train_set_percentage = The size of the train dataset as a percentage.